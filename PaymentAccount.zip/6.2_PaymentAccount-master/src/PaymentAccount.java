class PaymentAccount {

    private String outputBalance = "Ваш баланс: ";

    private long balance;

    long getBalance() {
        return balance;
    }

    void putMoney(long moneyAmount) {
        balance += moneyAmount;
        System.out.println(outputBalance + balance);
        System.out.println();
    }

    void withdrawMoney(long moneyAmount) {
        if (moneyAmount <= balance) {
            balance -= moneyAmount;
            System.out.println(outputBalance + balance);
            System.out.println();
        } else {
            System.out.println("Вы вводите сумму, которая больше Вашего баланса!");
            System.out.println();
        }
    }
}
