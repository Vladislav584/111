class CardAccount extends PaymentAccount {

    private final double PERCENT_WITHDRAW = 0.01;

    @Override
    void withdrawMoney(long moneyAmount) {
        long amountWithPercent = (long) (moneyAmount + moneyAmount * PERCENT_WITHDRAW);
        super.withdrawMoney(amountWithPercent);
    }
}