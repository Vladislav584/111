import java.time.LocalDateTime;

class DepositAccount extends PaymentAccount {

    private LocalDateTime timeTransaction = LocalDateTime.now();

    private final long TIME_LIMIT = 1;

    @Override
    void putMoney(long moneyAmount) {
        super.putMoney(moneyAmount);
        timeTransaction = LocalDateTime.now();
    }

    @Override
    void withdrawMoney(long moneyAmount) {
        LocalDateTime today = LocalDateTime.now();
        if (today.isAfter(timeTransaction.plusMonths(TIME_LIMIT))) {
            super.withdrawMoney(moneyAmount);
        } else System.out.println("Вы можете снять средства по истечении 1 месяца после последнего внесения");
    }
}
