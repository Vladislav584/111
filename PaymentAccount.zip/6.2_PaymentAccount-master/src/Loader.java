import java.util.Scanner;

public class Loader {

    public static void main(String[] args) {
        PaymentAccount paymentAccount = new PaymentAccount();
        DepositAccount depositAccount = new DepositAccount();
        CardAccount cardAccount = new CardAccount();

        String command = "Введите номер команды:\n1-Внести на счет\n2-Снять со счета\n3-Запрос баланса\n4-Выход\n";
        String put = "Введите сумму, которую хотите внести.";
        String withdraw = "Введите сумму, которую хотите снять.";
        String format = "Введите сумму!";
        String regex = "(\\d+)";


        for (; ; ) {

            System.out.println("Введите номер счета:\n1-Рассчетный счет\n2-Депозитный счет\n3-Карточный счет\n");

            Scanner scanner = new Scanner(System.in);
            String input = scanner.nextLine();

            if (input.equals("1")) {

                for (; ; ) {

                    System.out.println(command);

                    String input2 = scanner.nextLine();

                    if (input2.equals("1")) {
                        System.out.println(put);
                        String moneyAmount = scanner.nextLine();
                        if (String.valueOf(moneyAmount).matches(regex)) {
                            paymentAccount.putMoney(Long.parseLong(moneyAmount));
                        } else System.out.println(format);
                    }

                    if (input2.equals("2")) {
                        System.out.println(withdraw);
                        String moneyAmount = scanner.nextLine();
                        if (String.valueOf(moneyAmount).matches(regex)) {
                            paymentAccount.withdrawMoney(Long.parseLong(moneyAmount));
                        } else System.out.println(format);
                    }

                    if (input2.equals("3")) {
                        System.out.println("Баланс Вашего рассчетного счета : " + paymentAccount.getBalance());
                        System.out.println();
                    }
                    if (input2.equals("4")) {
                        break;
                    }
                }
            }

            if (input.equals("2")) {

                for (; ; ) {

                    System.out.println(command);

                    String input2 = scanner.nextLine();

                    if (input2.equals("1")) {
                        System.out.println(put);
                        String moneyAmount = scanner.nextLine();
                        if (String.valueOf(moneyAmount).matches(regex)) {
                            depositAccount.putMoney(Long.parseLong(moneyAmount));
                        } else System.out.println(format);
                    }
                    if (input2.equals("2")) {
                        System.out.println(withdraw);
                        String moneyAmount = scanner.nextLine();
                        if (String.valueOf(moneyAmount).matches(regex)) {
                            depositAccount.withdrawMoney(Long.parseLong(moneyAmount));
                        } else System.out.println(format);
                    }
                    if (input2.equals("3")) {
                        System.out.println("Баланс Вашего депозитного счета : " + depositAccount.getBalance());
                        System.out.println();
                    }
                    if (input2.equals("4")) {
                        break;
                    }
                }
            }

            if (input.equals("3")) {

                for (; ; ) {

                    System.out.println(command);

                    String input2 = scanner.nextLine();

                    if (input2.equals("1")) {
                        System.out.println(put);
                        String moneyAmount = scanner.nextLine();
                        if (String.valueOf(moneyAmount).matches(regex)) {
                            cardAccount.putMoney(Long.parseLong(moneyAmount));
                        } else System.out.println(format);
                    }
                    if (input2.equals("2")) {
                        System.out.println(withdraw);
                        String moneyAmount = scanner.nextLine();
                        if (String.valueOf(moneyAmount).matches(regex)) {
                            cardAccount.withdrawMoney(Long.parseLong(moneyAmount));
                        } else System.out.println(format);
                    }
                    if (input2.equals("3")) {
                        System.out.println("Баланс Вашего карточного счета : " + cardAccount.getBalance());
                        System.out.println();
                    }
                    if (input2.equals("4")) {
                        break;
                    }
                }
            }
        }
    }
}

